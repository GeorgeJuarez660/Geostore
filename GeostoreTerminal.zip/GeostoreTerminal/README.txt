ATTENZIONE

Assolutamente è vietato spostare il file db in un'altra directory, altrimenti il programma non effettuerà la connessione al db

CREDENZIALI

Accesso come Cliente ->

email: erika@gmail.com
password: Santa214

Accesso come Admin ->

email: elon@gmail.com
password: Senta321
codice admin: MCS214