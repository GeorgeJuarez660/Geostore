ATTENZIONE

Assolutamente è vietato spostare il file db in un'altra directory, altrimenti il programma non effettuerà la connessione al db

CREDENZIALI

Accesso come Cliente ->

email: george@gmail.com

Accesso come Admin ->

email: elon@gmail.com
codice admin: A5262